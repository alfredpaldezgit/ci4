<?php

namespace App\Controllers;

class easion extends BaseController
{
    public function index()
    {
        return view('easion/index');
    }

    public function blank()
    {
        return view('easion/blank');
    }


}
