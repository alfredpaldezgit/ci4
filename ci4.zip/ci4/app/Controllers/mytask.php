<?php

namespace App\Controllers;

class mytask extends BaseController
{
    public function index()
    {
        return view('task');
    }
}
