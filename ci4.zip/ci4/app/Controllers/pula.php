<?php

namespace App\Controllers;

class pula extends BaseController
{
    public function index()
    {
        return view('pula/index');
    }

    

}
